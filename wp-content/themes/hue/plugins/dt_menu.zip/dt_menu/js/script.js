(function($) { 
	"use strict";
	jQuery(document).ready(function($){
		$('#dt-menu-mobile').removeClass('hidden');
	});
 })(jQuery);